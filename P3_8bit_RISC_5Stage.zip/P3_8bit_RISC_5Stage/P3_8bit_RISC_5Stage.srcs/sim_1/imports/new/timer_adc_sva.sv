// timer_adc_sva.sv - assertions for the Timer/ADC peripheral (timer_adc8_top).
//
// Attached from the testbench with `bind` (see tb_risc8_soc.v, `ifdef SVA).
// It only WATCHES signals; the RTL is not modified.
//
// Time unit: every property is sampled on posedge clk and disabled while rst_n = 0.
// "|=>" means "at the next clock", $past(x) is the value of x one clock earlier.
//
// Groups:  T = timer, A = ADC controller, F = FIFO, R = register bus / read mux
`timescale 1ns/1ps

module timer_adc_sva (
    input logic       clk,
    input logic       rst_n,
    // bus
    input logic       psel,
    input logic       penable,
    input logic       pwrite,
    input logic [3:0] paddr,
    input logic [7:0] pwdata,
    input logic [7:0] prdata,
    // pins
    input logic       irq,
    input logic       pwm_out,
    input logic       adc_sample,
    input logic [1:0] adc_ch,
    input logic [7:0] adc_dac,
    input logic       adc_cmp,
    // timer
    input logic       tmr_en,
    input logic       tmr_oneshot,
    input logic [7:0] tmr_presc,
    input logic [7:0] tmr_load,
    input logic [7:0] tmr_cmp,
    input logic [7:0] tmr_cnt,
    input logic       tmr_ovf,
    input logic       tmr_cmp_match,
    input logic       tmr_stop,
    // adc
    input logic       adc_en,
    input logic       adc_start,
    input logic       adc_busy,
    input logic       adc_done,
    input logic [7:0] adc_smp,
    input logic [7:0] adc_div,
    input logic [7:0] thr_lo,
    input logic [7:0] thr_hi,
    input logic [7:0] res,
    // fifo
    input logic       fifo_pop,
    input logic       fifo_empty,
    input logic       fifo_full,
    input logic       fifo_ovr,
    input logic [3:0] fifo_level
);

    // a bus write / read happens when psel and penable are both high
    wire wr = psel && penable &&  pwrite;
    wire rd = psel && penable && !pwrite;

    // =====================================================================
    //  T : TIMER
    // =====================================================================

    // T1  The count never goes above LOAD (unless software lowered LOAD while it ran).
    a_t_cnt_le_load: assert property (@(posedge clk) disable iff (!rst_n)
        (tmr_en && tmr_cnt <= tmr_load) |=> (tmr_cnt <= $past(tmr_load)));

    // T2  EN = 0 holds the counter at 0.
    a_t_cnt_zero_off: assert property (@(posedge clk) disable iff (!rst_n)
        !tmr_en |=> tmr_cnt == 8'd0);

    // T3  OVF is a one-clock pulse (except LOAD = 0 and PRESC = 0, where it repeats every clock).
    a_t_ovf_1clk: assert property (@(posedge clk) disable iff (!rst_n)
        (tmr_ovf && (tmr_load != 8'd0 || tmr_presc != 8'd0)) |=> !tmr_ovf);

    // T4  OVF only comes from a running timer whose count had reached LOAD.
    a_t_ovf_cause: assert property (@(posedge clk) disable iff (!rst_n)
        tmr_ovf |-> ($past(tmr_en) && ($past(tmr_cnt) >= $past(tmr_load))));

    // T5  The count wraps to 0 at the same time as OVF.
    a_t_ovf_cnt0: assert property (@(posedge clk) disable iff (!rst_n)
        tmr_ovf |-> tmr_cnt == 8'd0);

    // T6  CMP match only when the count equalled CMP on a running timer.
    a_t_cmp_cause: assert property (@(posedge clk) disable iff (!rst_n)
        tmr_cmp_match |-> ($past(tmr_en) && ($past(tmr_cnt) == $past(tmr_cmp))));

    // T7  STOP is only produced by a one-shot timer, together with OVF.
    a_t_stop_cause: assert property (@(posedge clk) disable iff (!rst_n)
        tmr_stop |-> (tmr_ovf && $past(tmr_oneshot)));

    // T8  After STOP the hardware clears EN (a CPU write to TMR_CTRL in the same clock wins).
    a_t_oneshot_en: assert property (@(posedge clk) disable iff (!rst_n)
        (tmr_stop && !(wr && paddr == 4'h0)) |=> !tmr_en);

    // T9  PWM high means: timer was running and count < CMP in the previous clock.
    a_t_pwm_cause: assert property (@(posedge clk) disable iff (!rst_n)
        pwm_out |-> ($past(tmr_en) && ($past(tmr_cnt) < $past(tmr_cmp))));

    // T10 CMP = 0 gives 0 % duty.
    a_t_pwm_zero: assert property (@(posedge clk) disable iff (!rst_n)
        tmr_cmp == 8'd0 |=> !pwm_out);

    // T11 A stopped timer drives PWM low.
    a_t_pwm_off: assert property (@(posedge clk) disable iff (!rst_n)
        !tmr_en |=> !pwm_out);

    // =====================================================================
    //  A : ADC CONTROLLER
    // =====================================================================

    // A1  Sampling and DONE only happen while busy.
    a_a_sample_busy: assert property (@(posedge clk) disable iff (!rst_n)
        adc_sample |-> adc_busy);
    a_a_done_busy:   assert property (@(posedge clk) disable iff (!rst_n)
        adc_done   |-> adc_busy);

    // A2  SAMPLE and DONE are never active together.
    a_a_excl: assert property (@(posedge clk) disable iff (!rst_n)
        !(adc_sample && adc_done));

    // A3  DONE lasts one clock; the controller is idle right after it.
    a_a_done_idle: assert property (@(posedge clk) disable iff (!rst_n)
        adc_done |=> !adc_busy);

    // A4  DONE only follows a conversion that ran with EN = 1.
    a_a_done_en: assert property (@(posedge clk) disable iff (!rst_n)
        adc_done |-> $past(adc_en));

    // A5  Clearing EN aborts: idle and DAC = 0 in the next clock.
    a_a_abort_idle: assert property (@(posedge clk) disable iff (!rst_n)
        !adc_en |=> !adc_busy);
    a_a_abort_dac:  assert property (@(posedge clk) disable iff (!rst_n)
        !adc_en |=> adc_dac == 8'd0);

    // A6  The DAC is 0 during the sample window.
    a_a_dac_sample: assert property (@(posedge clk) disable iff (!rst_n)
        adc_sample |-> adc_dac == 8'd0);

    // A7  At DONE the DAC holds the final code, equal to the result.
    a_a_dac_res: assert property (@(posedge clk) disable iff (!rst_n)
        adc_done |-> adc_dac == res);

    // A8  The channel is latched at start and stays stable during the conversion.
    a_a_ch_stable: assert property (@(posedge clk) disable iff (!rst_n)
        (adc_busy && $past(adc_busy)) |-> $stable(adc_ch));

    // A9  The result register only changes when a conversion finishes.
    a_a_res_stable: assert property (@(posedge clk) disable iff (!rst_n)
        !adc_busy |=> $stable(res));

    // A10 Conversion time = (SMP + 1 + 8) * (DIV + 1) clocks from the first busy clock to the
    //     clock before DONE. Checked only if SMP/DIV were not rewritten during the conversion.
    integer     conv_cyc;
    logic       busy_q;
    logic       conv_stable;
    logic [7:0] smp_l, div_l;
    integer     conv_exp;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            busy_q      <= 1'b0;
            conv_cyc    <= 0;
            conv_stable <= 1'b1;
            smp_l       <= 8'd0;
            div_l       <= 8'd0;
        end else begin
            busy_q <= adc_busy;
            if (adc_busy && !busy_q) begin            // first busy clock
                smp_l       <= adc_smp;
                div_l       <= adc_div;
                conv_stable <= 1'b1;
                conv_cyc    <= 1;
            end else if (adc_busy) begin
                conv_cyc <= conv_cyc + 1;
                if (adc_smp !== smp_l || adc_div !== div_l)
                    conv_stable <= 1'b0;
            end else begin
                conv_cyc <= 0;
            end
        end
    end

    always_comb conv_exp = (smp_l + 9) * (div_l + 1);

    a_a_conv_time: assert property (@(posedge clk) disable iff (!rst_n)
        (adc_done && conv_stable && busy_q) |-> (conv_cyc == conv_exp))
        else $error("ADC conversion time: counted %0d clocks, expected %0d", conv_cyc, conv_exp);

    // =====================================================================
    //  F : RESULT FIFO  (depth 8)
    // =====================================================================

    a_f_empty_lvl: assert property (@(posedge clk) disable iff (!rst_n)
        fifo_empty == (fifo_level == 4'd0));
    a_f_full_lvl:  assert property (@(posedge clk) disable iff (!rst_n)
        fifo_full  == (fifo_level == 4'd8));
    a_f_lvl_max:   assert property (@(posedge clk) disable iff (!rst_n)
        fifo_level <= 4'd8);

    // F1  Overflow = a push while full and not popping.
    a_f_ovr_cause: assert property (@(posedge clk) disable iff (!rst_n)
        fifo_ovr |-> (fifo_full && adc_done && !fifo_pop));

    // F2  A dropped result leaves the level unchanged.
    a_f_ovr_hold: assert property (@(posedge clk) disable iff (!rst_n)
        fifo_ovr |=> fifo_level == $past(fifo_level));

    // F3  Push without pop: level + 1.
    a_f_push: assert property (@(posedge clk) disable iff (!rst_n)
        (adc_done && !fifo_full && !fifo_pop) |=> fifo_level == $past(fifo_level) + 4'd1);

    // F4  Pop without push: level - 1.
    a_f_pop: assert property (@(posedge clk) disable iff (!rst_n)
        (fifo_pop && !fifo_empty && !adc_done) |=> fifo_level == $past(fifo_level) - 4'd1);

    // F5  Push and pop together: level unchanged.
    a_f_push_pop: assert property (@(posedge clk) disable iff (!rst_n)
        (adc_done && fifo_pop && !fifo_empty) |=> $stable(fifo_level));

    // F6  Popping an empty FIFO does nothing.
    a_f_pop_empty: assert property (@(posedge clk) disable iff (!rst_n)
        (fifo_pop && fifo_empty && !adc_done) |=> fifo_empty);

    // F7  A pop happens exactly on a bus READ of ADC_DATA (0xA) - never on writes or other registers.
    a_f_pop_decode: assert property (@(posedge clk) disable iff (!rst_n)
        fifo_pop == (rd && paddr == 4'hA));

    // =====================================================================
    //  R : REGISTER BUS AND READ MUX
    // =====================================================================

    // R1  Read data is 0 when the peripheral is not selected (so it can be OR-ed with others).
    a_r_idle_zero: assert property (@(posedge clk) disable iff (!rst_n)
        !psel |-> prdata == 8'h00);

    // R2  Fixed read values and fields.
    a_r_id:   assert property (@(posedge clk) disable iff (!rst_n)
        (psel && paddr == 4'hF) |-> prdata == 8'hA8);
    a_r_stat: assert property (@(posedge clk) disable iff (!rst_n)
        (psel && paddr == 4'hC) |->
            prdata == {1'b0, adc_busy, fifo_full, fifo_empty, fifo_level});
    a_r_rch:  assert property (@(posedge clk) disable iff (!rst_n)
        (psel && paddr == 4'hB) |-> (prdata[7] == !fifo_empty && prdata[6:2] == 5'd0));
    a_r_cnt:  assert property (@(posedge clk) disable iff (!rst_n)
        (psel && paddr == 4'h4) |-> prdata == tmr_cnt);
    a_r_data_empty: assert property (@(posedge clk) disable iff (!rst_n)
        (psel && paddr == 4'hA && fifo_empty) |-> prdata == 8'h00);
    a_r_flags_hi: assert property (@(posedge clk) disable iff (!rst_n)
        (psel && (paddr == 4'hD || paddr == 4'hE)) |-> prdata[7:6] == 2'b00);
    a_r_ctrl_start0: assert property (@(posedge clk) disable iff (!rst_n)
        (psel && paddr == 4'h5) |-> (prdata[7:6] == 2'b00 && !prdata[1]));

    // R3  Write then read-back for the plain registers (takes effect one clock after the write).
    a_r_wr_presc: assert property (@(posedge clk) disable iff (!rst_n)
        (wr && paddr == 4'h1) |=> tmr_presc == $past(pwdata));
    a_r_wr_load:  assert property (@(posedge clk) disable iff (!rst_n)
        (wr && paddr == 4'h2) |=> tmr_load  == $past(pwdata));
    a_r_wr_cmp:   assert property (@(posedge clk) disable iff (!rst_n)
        (wr && paddr == 4'h3) |=> tmr_cmp   == $past(pwdata));
    a_r_wr_smp:   assert property (@(posedge clk) disable iff (!rst_n)
        (wr && paddr == 4'h6) |=> adc_smp   == $past(pwdata));
    a_r_wr_div:   assert property (@(posedge clk) disable iff (!rst_n)
        (wr && paddr == 4'h7) |=> adc_div   == $past(pwdata));
    a_r_wr_lo:    assert property (@(posedge clk) disable iff (!rst_n)
        (wr && paddr == 4'h8) |=> thr_lo    == $past(pwdata));
    a_r_wr_hi:    assert property (@(posedge clk) disable iff (!rst_n)
        (wr && paddr == 4'h9) |=> thr_hi    == $past(pwdata));

    // R4  START is a one-clock pulse, produced only by a write of ADC_CTRL with bit 1 = 1.
    a_r_start_cause: assert property (@(posedge clk) disable iff (!rst_n)
        adc_start |-> $past(wr && paddr == 4'h5 && pwdata[1]));
    a_r_start_1clk: assert property (@(posedge clk) disable iff (!rst_n)
        (adc_start && !(wr && paddr == 4'h5 && pwdata[1])) |=> !adc_start);

    // =====================================================================
    //  X : no unknown values on the outputs once reset is released
    // =====================================================================
    a_x_irq:   assert property (@(posedge clk) disable iff (!rst_n)
        !$isunknown(irq));
    a_x_pwm:   assert property (@(posedge clk) disable iff (!rst_n)
        !$isunknown(pwm_out));
    a_x_rdata: assert property (@(posedge clk) disable iff (!rst_n)
        !$isunknown(prdata));

endmodule
