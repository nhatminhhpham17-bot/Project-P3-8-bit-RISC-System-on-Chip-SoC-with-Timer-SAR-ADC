// afe_model.v - behavioral analog front end (Verilog-2001): 4 channels, Vref = 3.3 V.
// cmp = 1 when Vin(ch) >= DAC(code)   =>   result = floor(Vin/Vref*256)
module afe_model (
    input  wire       adc_sample,
    input  wire [1:0] adc_ch,
    input  wire [7:0] adc_dac,
    output wire       adc_cmp
);
    // input voltages in millivolts (change from the testbench if you like)
    integer vin_mv0 = 400;    // -> 0x1F
    integer vin_mv1 = 1111;   // -> 0x56
    integer vin_mv2 = 2000;   // -> 0x9B
    integer vin_mv3 = 3000;   // -> 0xE8
    integer vsel;
    always @* begin
        case (adc_ch)
            2'd0: vsel = vin_mv0;
            2'd1: vsel = vin_mv1;
            2'd2: vsel = vin_mv2;
            default: vsel = vin_mv3;
        endcase
    end
    assign adc_cmp = ((vsel * 256) >= (adc_dac * 3300));
endmodule
