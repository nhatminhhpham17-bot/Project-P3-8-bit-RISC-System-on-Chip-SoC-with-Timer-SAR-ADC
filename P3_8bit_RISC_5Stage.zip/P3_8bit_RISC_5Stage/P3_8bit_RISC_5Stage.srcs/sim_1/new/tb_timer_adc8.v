`timescale 1ns/1ps
// Stand-alone testbench for the Timer/ADC peripheral through the CPU-style port.
module tb_timer_adc8;
    reg clk = 0, rst_n = 0;
    reg cs = 0, we = 0; reg [3:0] addr = 0; reg [7:0] wdata = 0;
    wire [7:0] rdata; wire irq, pwm_out, adc_sample, adc_cmp; wire [1:0] adc_ch; wire [7:0] adc_dac;

    always #5 clk = ~clk;

    timer_adc8_cpu_if dut (.clk(clk), .rst_n(rst_n), .cs(cs), .we(we), .addr(addr), .wdata(wdata),
        .rdata(rdata), .irq(irq), .adc_sample(adc_sample), .adc_ch(adc_ch), .adc_dac(adc_dac),
        .adc_cmp(adc_cmp), .pwm_out(pwm_out));
    afe_model afe (.adc_sample(adc_sample), .adc_ch(adc_ch), .adc_dac(adc_dac), .adc_cmp(adc_cmp));

    integer errors = 0, checks = 0;
    reg [7:0] rv;

    // one-clock bus accesses, exactly like the CPU's MEM stage
    task bus_wr(input [3:0] a, input [7:0] d); begin
        @(negedge clk); cs = 1; we = 1; addr = a; wdata = d;
        @(negedge clk); cs = 0; we = 0;
    end endtask
    task bus_rd(input [3:0] a); begin
        @(negedge clk); cs = 1; we = 0; addr = a;
        #1 rv = rdata;                       // same-clock read data
        @(negedge clk); cs = 0;
    end endtask
    task check(input [255:0] name, input [7:0] got, input [7:0] exp); begin
        checks = checks + 1;
        if (got !== exp) begin errors = errors + 1; $display("FAIL: %0s got %h exp %h", name, got, exp); end
        else $display("PASS: %0s = %h", name, got);
    end endtask
    task wait_not_busy; integer n; begin
        n = 0; rv = 8'h40;
        while (rv[6] && n < 500) begin bus_rd(4'hC); n = n + 1; end
    end endtask

    integer hi, i;
    initial begin
        repeat (3) @(negedge clk); rst_n = 1;

        bus_rd(4'hF);  check("ID", rv, 8'hA8);
        bus_rd(4'hC);  check("STAT reset (empty)", rv, 8'h10);

        // --- B: single software conversion on ch1 ---
        bus_wr(4'h6, 8'd3); bus_wr(4'h7, 8'd0); bus_wr(4'h5, 8'h13);
        bus_rd(4'hC);  check("STAT busy+empty", rv, 8'h50);
        wait_not_busy;
        bus_rd(4'hC);  check("STAT level 1", rv, 8'h01);
        bus_rd(4'hB);  check("RCH valid ch1", rv, 8'h81);
        bus_rd(4'hA);  check("DATA ch1 1.111V", rv, 8'h56);
        bus_rd(4'hC);  check("STAT empty after pop", rv, 8'h10);
        bus_rd(4'hB);  check("RCH empty", rv, 8'h00);
        bus_rd(4'hE);  check("IRQ_STAT EOC", rv, 8'h04);
        bus_wr(4'hE, 8'h04);
        bus_rd(4'hE);  check("IRQ_STAT cleared", rv, 8'h00);

        // --- DIV > 0 and all channels ---
        bus_wr(4'h7, 8'd2);
        for (i = 0; i < 4; i = i + 1) begin
            bus_wr(4'h5, 8'h03 | (i << 4));
            wait_not_busy;
        end
        bus_rd(4'hA);  check("ch0 0.40V", rv, 8'h1F);
        bus_rd(4'hB);  check("RCH ch1", rv, 8'h81);
        bus_rd(4'hA);  check("ch1 1.111V", rv, 8'h56);
        bus_rd(4'hA);  check("ch2 2.0V", rv, 8'h9B);
        bus_rd(4'hA);  check("ch3 3.0V", rv, 8'hE8);
        bus_wr(4'h7, 8'd0);

        // --- C: timer-triggered conversions on ch2, 100-clock period ---
        bus_wr(4'hE, 8'h1F);
        bus_wr(4'h1, 8'd3); bus_wr(4'h2, 8'd24); bus_wr(4'h3, 8'd12);
        bus_wr(4'h5, 8'h25);                 // EN, timer-overflow trigger, ch2
        bus_wr(4'h0, 8'h01);                 // timer EN
        for (i = 0; i < 4; i = i + 1) begin
            rv = 8'h10;
            while (rv[4]) bus_rd(4'hC);
            bus_rd(4'hB); check("timer-trig RCH ch2", rv, 8'h82);
            bus_rd(4'hA); check("timer-trig ch2 2.0V", rv, 8'h9B);
        end
        bus_wr(4'h0, 8'h00); bus_wr(4'h5, 8'h00);
        repeat (20) @(negedge clk);
        while (!dut.u_top.u_regs.fifo_empty) bus_rd(4'hA);   // drain
        bus_rd(4'hE);  check("flags OVF|CMP|EOC", rv & 8'h07, 8'h07);
        bus_wr(4'hE, 8'h04);
        bus_rd(4'hE);  check("flags after W1C EOC", rv & 8'h07, 8'h03);
        bus_wr(4'hE, 8'h1F);

        // --- D: watchdog + irq pin ---
        bus_wr(4'h9, 8'd100); bus_wr(4'hD, 8'h08);
        bus_wr(4'h5, 8'h33);                 // ch3, start
        wait_not_busy;
        checks = checks + 1;
        if (irq !== 1'b1) begin errors = errors + 1; $display("FAIL: irq should be high"); end
        else $display("PASS: irq high");
        bus_rd(4'hE);  check("IRQ_STAT EOC|WD", rv, 8'h0C);
        bus_rd(4'hA);  check("ch3 3.0V", rv, 8'hE8);
        bus_wr(4'hE, 8'h0C);
        checks = checks + 1;
        if (irq !== 1'b0) begin errors = errors + 1; $display("FAIL: irq should be low"); end
        else $display("PASS: irq cleared");
        bus_wr(4'hD, 8'h00); bus_wr(4'h9, 8'hFF);

        // --- F: two queued results, pops, FIFO order ---
        bus_wr(4'h5, 8'h03); wait_not_busy;
        bus_wr(4'h5, 8'h13); wait_not_busy;
        bus_rd(4'hC);  check("STAT level 2", rv, 8'h02);
        bus_rd(4'hA);  check("1st pop ch0", rv, 8'h1F);
        bus_rd(4'hA);  check("2nd pop ch1", rv, 8'h56);
        bus_rd(4'hC);  check("STAT empty", rv, 8'h10);

        // --- FIFO full / overflow ---
        for (i = 0; i < 9; i = i + 1) begin bus_wr(4'h5, 8'h03); wait_not_busy; end
        bus_rd(4'hC);  check("STAT full", rv, 8'h28);
        bus_rd(4'hE);  check("FIFO_OVR flag", rv & 8'h10, 8'h10);
        bus_wr(4'hE, 8'h1F);
        for (i = 0; i < 8; i = i + 1) bus_rd(4'hA);
        bus_rd(4'hC);  check("STAT empty again", rv, 8'h10);

        // --- E: PWM 30 % ---
        bus_wr(4'h1, 8'd0); bus_wr(4'h2, 8'd9); bus_wr(4'h3, 8'd3);
        bus_wr(4'h0, 8'h01);
        repeat (20) @(negedge clk);
        hi = 0;
        for (i = 0; i < 100; i = i + 1) begin @(negedge clk); if (pwm_out) hi = hi + 1; end
        checks = checks + 1;
        if (hi !== 30) begin errors = errors + 1; $display("FAIL: PWM high %0d of 100", hi); end
        else $display("PASS: PWM high 30 of 100 clocks");

        // --- one-shot ---
        bus_wr(4'h0, 8'h00); bus_wr(4'hE, 8'h1F);
        bus_wr(4'h1, 8'd1); bus_wr(4'h2, 8'd4);
        bus_wr(4'h0, 8'h03);
        repeat (30) @(negedge clk);
        bus_rd(4'h0);  check("one-shot EN auto-clears", rv, 8'h02);
        bus_rd(4'hE);  check("one-shot OVF once set", rv & 8'h01, 8'h01);

        $display("--------------------------------------------------");
        if (errors == 0) $display("*** PERIPHERAL TEST PASSED *** (%0d checks)", checks);
        else             $display("*** PERIPHERAL TEST FAILED *** (%0d of %0d)", errors, checks);
        $finish;
    end

    initial begin #2000000; $display("TIMEOUT"); $finish; end
endmodule
