`define SVA
`timescale 1ns/1ps
// tb/tb_risc8_soc.v - Full system testbench: RISC-8 CPU + Timer/ADC peripheral + AFE model
module tb_risc8_soc;
    reg        clk = 0;
    reg        rst = 1;
    wire       halted;
    wire [7:0] pc_out;
    wire       irq, pwm_out, adc_sample, adc_cmp;
    wire [1:0] adc_ch;
    wire [7:0] adc_dac;

    always #5 clk = ~clk; // 100 MHz clock

  risc8_soc #(
        .IMEM_FILE("")   // <-- Sửa thành chuỗi rỗng để ép dùng mảng ROM cứng bên trong imem.v
    ) dut (
        .clk        (clk),
        .rst        (rst),
        .halted     (halted),
        .pc_out     (pc_out),
        .flags_out  (),
        .instr_done (),
        .irq        (irq),
        .pwm_out    (pwm_out),
        .adc_sample (adc_sample),
        .adc_ch     (adc_ch),
        .adc_dac    (adc_dac),
        .adc_cmp    (adc_cmp)
    );

    afe_model u_afe (
        .adc_sample (adc_sample),
        .adc_ch     (adc_ch),
        .adc_dac    (adc_dac),
        .adc_cmp    (adc_cmp)
    );

    `ifdef SVA
    bind timer_adc8_top timer_adc_sva u_sva (
        .clk            (clk),
        .rst_n          (rst_n),
        .psel           (psel),
        .penable        (penable),
        .pwrite         (pwrite),
        .paddr          (paddr),
        .pwdata         (pwdata),
        .prdata         (prdata),
        .irq            (irq),
        .pwm_out        (pwm_out),
        .adc_sample     (adc_sample),
        .adc_ch         (adc_ch),
        .adc_dac        (adc_dac),
        .adc_cmp        (adc_cmp),
        .tmr_en         (tmr_en),
        .tmr_oneshot    (tmr_oneshot),
        .tmr_presc      (tmr_presc),
        .tmr_load       (tmr_load),
        .tmr_cmp        (tmr_cmp),
        .tmr_cnt        (tmr_cnt),
        .tmr_ovf        (tmr_ovf),
        .tmr_cmp_match  (tmr_cmp_match),
        .tmr_stop       (tmr_stop),
        .adc_en         (adc_en),
        .adc_start      (adc_start),
        .adc_busy       (adc_busy),
        .adc_done       (adc_done),
        .adc_smp        (adc_smp),
        .adc_div        (adc_div),
        .thr_lo         (thr_lo),
        .thr_hi         (thr_hi),
        .res            (res),
        .fifo_pop       (fifo_pop),
        .fifo_empty     (fifo_empty),
        .fifo_full      (fifo_full),
        .fifo_ovr       (fifo_ovr),
        .fifo_level     (fifo_level)
    );
    `endif

    integer cycles = 0;
    integer io_accesses = 0;
    integer errors = 0;
    integer checks = 0;
    integer trace_fd;
    reg     irq_seen_high = 0;

    always @(posedge clk) begin
        if (!rst) begin
            cycles <= cycles + 1;
            if (dut.io_cs)
                io_accesses <= io_accesses + 1;
            if (irq)
                irq_seen_high <= 1'b1;
            if (trace_fd != 0) begin
                $fwrite(trace_fd, "%0d,%02h,%02h,%0d,%0d,%01h,%02h,%02h\n",
                        cycles, pc_out, dut.u_cpu.exmem_addr,
                        dut.io_cs, dut.io_we, dut.io_addr, dut.io_wdata, dut.io_rdata);
            end
        end
    end

    task check_mem(input [7:0] addr, input [7:0] exp, input [255:0] desc);
        reg [7:0] got;
        begin
            got = dut.u_cpu.u_dmem.mem[addr];
            checks = checks + 1;
            if (got !== exp) begin
                errors = errors + 1;
                $display("FAIL: MEM[%02h] = %02h (expected %02h) - %0s", addr, got, exp, desc);
            end else begin
                $display("PASS: MEM[%02h] = %02h  %0s", addr, got, desc);
            end
        end
    endtask

    integer i, pwm_hi;
    initial begin
        `ifdef DUMP
        $dumpfile("risc8_soc.vcd");
        $dumpvars(0, tb_risc8_soc);
        `endif

        trace_fd = $fopen("io_trace.csv", "w");
        if (trace_fd != 0)
            $fwrite(trace_fd, "cycle,pc,exmem_addr,io_cs,io_we,io_addr,io_wdata,io_rdata\n");

        repeat (3) @(posedge clk);
        rst <= 0;

        // Wait for CPU to hit HLT
        while (!halted && cycles < 5000) @(posedge clk);

        $display("CPU halted after %0d cycles, %0d I/O accesses", cycles, io_accesses);

        // Check 1: CPU halted cleanly
        checks = checks + 1;
        if (!halted) begin
            errors = errors + 1;
            $display("FAIL: CPU did not halt (timeout)");
        end

        // Checks 2..19: RAM 0x80..0x91
        check_mem(8'h80, 8'hA8, "ID register");
        check_mem(8'h81, 8'h81, "B: ADC_RCH = valid, ch1");
        check_mem(8'h82, 8'h56, "B: ch1 code (1.111 V)");
        check_mem(8'h83, 8'h82, "C: ADC_RCH = valid, ch2");
        check_mem(8'h84, 8'h9B, "C: ch2 code (2.0 V), timer start");
        check_mem(8'h85, 8'h82, "C: ADC_RCH = valid, ch2");
        check_mem(8'h86, 8'h9B, "C: ch2 code (2.0 V), timer start");
        check_mem(8'h87, 8'h82, "C: ADC_RCH = valid, ch2");
        check_mem(8'h88, 8'h9B, "C: ch2 code (2.0 V), timer start");
        check_mem(8'h89, 8'h82, "C: ADC_RCH = valid, ch2");
        check_mem(8'h8A, 8'h9B, "C: ch2 code (2.0 V), timer start");
        check_mem(8'h8B, 8'h07, "C: IRQ_STAT = OVF|CMP|EOC");
        check_mem(8'h8C, 8'h03, "C: IRQ_STAT after W1C 0x04");
        check_mem(8'h8D, 8'h0C, "D: IRQ_STAT = EOC|WD");
        check_mem(8'h8E, 8'hE8, "D: ch3 code (3.0 V)");
        check_mem(8'h8F, 8'h1F, "F: 1st pop, ch0 code (0.40 V)");
        check_mem(8'h90, 8'h56, "F: 2nd pop, ch1 code (1.111 V)");
        check_mem(8'h91, 8'h10, "F: ADC_STAT = empty after 2 pops");

        // Check 20 & 21: irq pin rose during Part D and was cleared
        checks = checks + 2;
        if (!irq_seen_high || irq !== 1'b0) begin
            errors = errors + 1;
            $display("FAIL: irq pin check (seen_high=%b, now=%b)", irq_seen_high, irq);
        end else begin
            $display("PASS: irq pin went high during part D and was cleared");
        end

        // Check 22: PWM running at 30% duty while CPU is halted
        pwm_hi = 0;
        for (i = 0; i < 100; i = i + 1) begin
            @(negedge clk);
            if (pwm_out) pwm_hi = pwm_hi + 1;
        end
        checks = checks + 1;
        if (pwm_hi !== 30) begin
            errors = errors + 1;
            $display("FAIL: PWM high for %0d of 100 clocks (expected 30)", pwm_hi);
        end else begin
            $display("PASS: PWM high for 30 of 100 clocks");
        end

        if (trace_fd != 0) $fclose(trace_fd);

        if (errors == 0)
            $display("*** SOC TEST PASSED *** (%0d checks)", checks);
        else
            $display("*** SOC TEST FAILED *** (%0d errors of %0d checks)", errors, checks);
        $finish;
    end
endmodule