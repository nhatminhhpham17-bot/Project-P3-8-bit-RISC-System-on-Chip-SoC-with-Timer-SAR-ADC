`timescale 1ns/1ps

(* KEEP_HIERARCHY = "yes" *)
module imem #(
    parameter INIT_FILE    = "",
    parameter USE_SOC_DEMO = 1    // 1 = SoC demo (tb_risc8_soc), 0 = basic core test (tb_risc8_5stage)
) (
    input  wire [7:0]  addr,
    output wire [15:0] instr
);

    (* rom_style = "distributed" *) reg [15:0] rom [0:255];
    integer i;

    // Instruction format: op[15:12] rd[11:9] rs1[8:6] rs2[5:3] imm8[7:0]
    //   LDI rd,imm   = 8<<12 | rd<<9 | imm
    //   LD  rd,[rs1] = A<<12 | rd<<9 | rs1<<6
    //   ST  [rs1],rd = B<<12 | rd<<9 | rs1<<6      (rd = data register)
    initial begin
        for (i = 0; i < 256; i = i + 1) rom[i] = 16'h0000;

        if (INIT_FILE != "") begin
            $readmemh(INIT_FILE, rom);
        end else if (USE_SOC_DEMO != 0) begin
            // ---------------- SoC demo (150 instructions) ----------------
            rom[0  ] = 16'h8EFF;   // LDI r7,0xFF
            rom[1  ] = 16'hA3C0;   // LD r1,[r7]
            rom[2  ] = 16'h8C80;   // LDI r6,0x80
            rom[3  ] = 16'hB380;   // ST [r6],r1
            rom[4  ] = 16'h8410;   // LDI r2,0x10
            rom[5  ] = 16'h8601;   // LDI r3,0x01
            rom[6  ] = 16'h8EF6;   // LDI r7,0xF6
            rom[7  ] = 16'h8203;   // LDI r1,0x03
            rom[8  ] = 16'hB3C0;   // ST [r7],r1
            rom[9  ] = 16'h8EF7;   // LDI r7,0xF7
            rom[10 ] = 16'h8200;   // LDI r1,0x00
            rom[11 ] = 16'hB3C0;   // ST [r7],r1
            rom[12 ] = 16'h8EF5;   // LDI r7,0xF5
            rom[13 ] = 16'h8213;   // LDI r1,0x13
            rom[14 ] = 16'hB3C0;   // ST [r7],r1
            rom[15 ] = 16'h8EFC;   // LDI r7,0xFC
            rom[16 ] = 16'hA1C0;   // LD r0,[r7]
            rom[17 ] = 16'h3010;   // AND r0,r0,r2
            rom[18 ] = 16'hE010;   // BNZ pn16 (0x10)
            rom[19 ] = 16'h8EFB;   // LDI r7,0xFB
            rom[20 ] = 16'hA1C0;   // LD r0,[r7]
            rom[21 ] = 16'h8C81;   // LDI r6,0x81
            rom[22 ] = 16'hB180;   // ST [r6],r0
            rom[23 ] = 16'h8EFA;   // LDI r7,0xFA
            rom[24 ] = 16'hA1C0;   // LD r0,[r7]
            rom[25 ] = 16'h8C82;   // LDI r6,0x82
            rom[26 ] = 16'hB180;   // ST [r6],r0
            rom[27 ] = 16'h8EFE;   // LDI r7,0xFE
            rom[28 ] = 16'h821F;   // LDI r1,0x1F
            rom[29 ] = 16'hB3C0;   // ST [r7],r1
            rom[30 ] = 16'h8EF1;   // LDI r7,0xF1
            rom[31 ] = 16'h8203;   // LDI r1,0x03
            rom[32 ] = 16'hB3C0;   // ST [r7],r1
            rom[33 ] = 16'h8EF2;   // LDI r7,0xF2
            rom[34 ] = 16'h8218;   // LDI r1,0x18
            rom[35 ] = 16'hB3C0;   // ST [r7],r1
            rom[36 ] = 16'h8EF3;   // LDI r7,0xF3
            rom[37 ] = 16'h820C;   // LDI r1,0x0C
            rom[38 ] = 16'hB3C0;   // ST [r7],r1
            rom[39 ] = 16'h8EF5;   // LDI r7,0xF5
            rom[40 ] = 16'h8225;   // LDI r1,0x25
            rom[41 ] = 16'hB3C0;   // ST [r7],r1
            rom[42 ] = 16'h8EF0;   // LDI r7,0xF0
            rom[43 ] = 16'h8201;   // LDI r1,0x01
            rom[44 ] = 16'hB3C0;   // ST [r7],r1
            rom[45 ] = 16'h8C83;   // LDI r6,0x83
            rom[46 ] = 16'h8A04;   // LDI r5,0x04
            rom[47 ] = 16'h8EFC;   // LDI r7,0xFC
            rom[48 ] = 16'hA1C0;   // LD r0,[r7]
            rom[49 ] = 16'h3010;   // AND r0,r0,r2
            rom[50 ] = 16'hE030;   // BNZ pollC (0x30)
            rom[51 ] = 16'h8EFB;   // LDI r7,0xFB
            rom[52 ] = 16'hA1C0;   // LD r0,[r7]
            rom[53 ] = 16'hB180;   // ST [r6],r0
            rom[54 ] = 16'h9C01;   // ADDI r6,1
            rom[55 ] = 16'h8EFA;   // LDI r7,0xFA
            rom[56 ] = 16'hA1C0;   // LD r0,[r7]
            rom[57 ] = 16'hB180;   // ST [r6],r0
            rom[58 ] = 16'h9C01;   // ADDI r6,1
            rom[59 ] = 16'h2B58;   // SUB r5,r5,r3
            rom[60 ] = 16'hE02F;   // BNZ loopC (0x2F)
            rom[61 ] = 16'h8EF0;   // LDI r7,0xF0
            rom[62 ] = 16'h8200;   // LDI r1,0x00
            rom[63 ] = 16'hB3C0;   // ST [r7],r1
            rom[64 ] = 16'h8EF5;   // LDI r7,0xF5
            rom[65 ] = 16'hB3C0;   // ST [r7],r1
            rom[66 ] = 16'h8EFE;   // LDI r7,0xFE
            rom[67 ] = 16'hA1C0;   // LD r0,[r7]
            rom[68 ] = 16'h8C8B;   // LDI r6,0x8B
            rom[69 ] = 16'hB180;   // ST [r6],r0
            rom[70 ] = 16'h8204;   // LDI r1,0x04
            rom[71 ] = 16'hB3C0;   // ST [r7],r1
            rom[72 ] = 16'h8EFE;   // LDI r7,0xFE
            rom[73 ] = 16'hA1C0;   // LD r0,[r7]
            rom[74 ] = 16'h8C8C;   // LDI r6,0x8C
            rom[75 ] = 16'hB180;   // ST [r6],r0
            rom[76 ] = 16'h8EFE;   // LDI r7,0xFE
            rom[77 ] = 16'h821F;   // LDI r1,0x1F
            rom[78 ] = 16'hB3C0;   // ST [r7],r1
            rom[79 ] = 16'h8EF9;   // LDI r7,0xF9
            rom[80 ] = 16'h8264;   // LDI r1,0x64
            rom[81 ] = 16'hB3C0;   // ST [r7],r1
            rom[82 ] = 16'h8EFD;   // LDI r7,0xFD
            rom[83 ] = 16'h8208;   // LDI r1,0x08
            rom[84 ] = 16'hB3C0;   // ST [r7],r1
            rom[85 ] = 16'h8EF5;   // LDI r7,0xF5
            rom[86 ] = 16'h8233;   // LDI r1,0x33
            rom[87 ] = 16'hB3C0;   // ST [r7],r1
            rom[88 ] = 16'h8EFC;   // LDI r7,0xFC
            rom[89 ] = 16'hA1C0;   // LD r0,[r7]
            rom[90 ] = 16'h3010;   // AND r0,r0,r2
            rom[91 ] = 16'hE059;   // BNZ pn89 (0x59)
            rom[92 ] = 16'h8EFE;   // LDI r7,0xFE
            rom[93 ] = 16'hA1C0;   // LD r0,[r7]
            rom[94 ] = 16'h8C8D;   // LDI r6,0x8D
            rom[95 ] = 16'hB180;   // ST [r6],r0
            rom[96 ] = 16'h8EFA;   // LDI r7,0xFA
            rom[97 ] = 16'hA1C0;   // LD r0,[r7]
            rom[98 ] = 16'h8C8E;   // LDI r6,0x8E
            rom[99 ] = 16'hB180;   // ST [r6],r0
            rom[100] = 16'h8EFE;   // LDI r7,0xFE
            rom[101] = 16'h821F;   // LDI r1,0x1F
            rom[102] = 16'hB3C0;   // ST [r7],r1
            rom[103] = 16'h8EFD;   // LDI r7,0xFD
            rom[104] = 16'h8200;   // LDI r1,0x00
            rom[105] = 16'hB3C0;   // ST [r7],r1
            rom[106] = 16'h8EF9;   // LDI r7,0xF9
            rom[107] = 16'h82FF;   // LDI r1,0xFF
            rom[108] = 16'hB3C0;   // ST [r7],r1
            rom[109] = 16'h8EF5;   // LDI r7,0xF5
            rom[110] = 16'h8203;   // LDI r1,0x03
            rom[111] = 16'hB3C0;   // ST [r7],r1
            rom[112] = 16'h8EFC;   // LDI r7,0xFC
            rom[113] = 16'hA1C0;   // LD r0,[r7]
            rom[114] = 16'h3010;   // AND r0,r0,r2
            rom[115] = 16'hE071;   // BNZ pn113 (0x71)
            rom[116] = 16'h8EF5;   // LDI r7,0xF5
            rom[117] = 16'h8213;   // LDI r1,0x13
            rom[118] = 16'hB3C0;   // ST [r7],r1
            rom[119] = 16'h8802;   // LDI r4,0x02
            rom[120] = 16'h8EFC;   // LDI r7,0xFC
            rom[121] = 16'hA1C0;   // LD r0,[r7]
            rom[122] = 16'h3020;   // AND r0,r0,r4
            rom[123] = 16'hD079;   // BZ pollF (0x79)
            rom[124] = 16'h8EFA;   // LDI r7,0xFA
            rom[125] = 16'h8000;   // LDI r0,0x00
            rom[126] = 16'h19C0;   // ADD r4,r7,r0
            rom[127] = 16'hA100;   // LD r0,[r4]
            rom[128] = 16'hAB00;   // LD r5,[r4]
            rom[129] = 16'h8C8F;   // LDI r6,0x8F
            rom[130] = 16'hB180;   // ST [r6],r0
            rom[131] = 16'h8C90;   // LDI r6,0x90
            rom[132] = 16'hBB80;   // ST [r6],r5
            rom[133] = 16'h8EFC;   // LDI r7,0xFC
            rom[134] = 16'hA1C0;   // LD r0,[r7]
            rom[135] = 16'h8C91;   // LDI r6,0x91
            rom[136] = 16'hB180;   // ST [r6],r0
            rom[137] = 16'h8EF1;   // LDI r7,0xF1
            rom[138] = 16'h8200;   // LDI r1,0x00
            rom[139] = 16'hB3C0;   // ST [r7],r1
            rom[140] = 16'h8EF2;   // LDI r7,0xF2
            rom[141] = 16'h8209;   // LDI r1,0x09
            rom[142] = 16'hB3C0;   // ST [r7],r1
            rom[143] = 16'h8EF3;   // LDI r7,0xF3
            rom[144] = 16'h8203;   // LDI r1,0x03
            rom[145] = 16'hB3C0;   // ST [r7],r1
            rom[146] = 16'h8EF0;   // LDI r7,0xF0
            rom[147] = 16'h8201;   // LDI r1,0x01
            rom[148] = 16'hB3C0;   // ST [r7],r1
            rom[149] = 16'hF000;   // HLT
        end else begin
            // ---------------- Basic core test (14 instructions) ----------------
            rom[0  ] = 16'h8203;   // LDI r1,0x03
            rom[1  ] = 16'h840F;   // LDI r2,0x0F
            rom[2  ] = 16'h8601;   // LDI r3,0x01
            rom[3  ] = 16'h8820;   // LDI r4,0x20
            rom[4  ] = 16'hB500;   // ST [r4],r2
            rom[5  ] = 16'hAD00;   // LD r6,[r4]
            rom[6  ] = 16'h9C57;   // ADDI r6,87
            rom[7  ] = 16'h2258;   // SUB r1,r1,r3
            rom[8  ] = 16'hE007;   // BNZ lp (0x07)
            rom[9  ] = 16'h8AFF;   // LDI r5,0xFF
            rom[10 ] = 16'h9A01;   // ADDI r5,1
            rom[11 ] = 16'hC00D;   // JMP end (0x0D)
            rom[12 ] = 16'h8E77;   // LDI r7,0x77
            rom[13 ] = 16'hF000;   // HLT
        end
    end

    assign instr = rom[addr];

endmodule