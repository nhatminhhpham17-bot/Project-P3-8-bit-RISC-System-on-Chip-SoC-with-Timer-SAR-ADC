// timer8.v - 8-bit timer with prescaler, compare, one-shot and PWM output.
//   tick every (presc+1) clocks; period = (load+1) ticks; counts 0..load.
//   cmp_match : pulse when count == cmp on a tick
//   ovf       : pulse when count wraps (count == load on a tick)
//   pwm_out   : high while count < cmp (cmp=0 -> 0 %, cmp>load -> 100 %)
//   stop      : pulse in one-shot mode after the overflow (tells the register
//               block to clear EN)
// While en = 0 the prescaler and counter are held at 0.
module timer8 (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       en,
    input  wire       oneshot,
    input  wire [7:0] presc,
    input  wire [7:0] load,
    input  wire [7:0] cmp,
    output wire [7:0] cnt,
    output reg        ovf,
    output reg        cmp_match,
    output reg        stop,
    output reg        pwm_out
);
    reg [7:0] psc;
    reg [7:0] count;
    reg       halted;                   // one-shot finished, wait for EN to drop

    assign cnt = count;

    wire run  = en && !halted;
    wire tick = (psc >= presc);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            psc       <= 8'd0;
            count     <= 8'd0;
            halted    <= 1'b0;
            ovf       <= 1'b0;
            cmp_match <= 1'b0;
            stop      <= 1'b0;
            pwm_out   <= 1'b0;
        end else begin
            ovf       <= 1'b0;
            cmp_match <= 1'b0;
            stop      <= 1'b0;

            if (!en) begin
                halted <= 1'b0;
                psc    <= 8'd0;
                count  <= 8'd0;
            end else if (run) begin
                if (tick) begin
                    psc <= 8'd0;
                    if (count == cmp)
                        cmp_match <= 1'b1;
                    if (count >= load) begin
                        count <= 8'd0;
                        ovf   <= 1'b1;
                        if (oneshot) begin
                            halted <= 1'b1;
                            stop   <= 1'b1;
                        end
                    end else begin
                        count <= count + 8'd1;
                    end
                end else begin
                    psc <= psc + 8'd1;
                end
            end

            pwm_out <= run && (count < cmp);
        end
    end
endmodule
